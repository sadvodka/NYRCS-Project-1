<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="props" tilewidth="32" tileheight="32" tilecount="99" columns="11">
 <image source="../../dungeon tileset 2/Tiles-Props-pack.png" width="352" height="288"/>
</tileset>
